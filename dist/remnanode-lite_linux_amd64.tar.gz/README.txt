remnanode-lite v1.1.1 linux/amd64

由 scripts/build-dist.sh 从本仓库源码构建；安装脚本会自动使用本资产。
解压后安装到 /usr/local/bin/remnanode-lite
